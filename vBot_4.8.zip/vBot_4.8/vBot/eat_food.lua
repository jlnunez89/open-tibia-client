setDefaultTab("HP")
if voc() ~= 1 and voc() ~= 11 then
    if storage.foodItems then
        local t = {}
        for i, v in pairs(storage.foodItems) do
            if not table.find(t, v.id) then
                table.insert(t, v.id)
            end
        end
        local foodItems = { 3607, 3585, 3592, 3600, 3601 }
        for i, item in pairs(foodItems) do
            if not table.find(t, item) then
                table.insert(storage.foodItems, item)
            end
        end
    end
    macro(500, "Cast Food", function()
        if player:getRegenerationTime() <= 400 then
            cast("exevo pan", 5000)
        end
    end)
end

UI.Label("Eatable items:")
if type(storage.foodItems) ~= "table" then
  storage.foodItems = {3582, 3577}
end

local foodContainer = UI.Container(function(widget, items)
  storage.foodItems = items
end, true)
foodContainer:setHeight(35)
foodContainer:setItems(storage.foodItems)

do
  local eatBackoff = 500       -- current delay between attempts (ms)
  local eatBackoffMin = 500
  local eatBackoffMax = 30000  -- cap at 30s
  local lastRegenTime = 0

  macro(500, "Eat Food", function()
    if not storage.foodItems[1] then return end

    local regenTime = player:getRegenerationTime()
    if regenTime > 400 then
      -- still full, back off exponentially
      eatBackoff = math.min(eatBackoff * 2, eatBackoffMax)
      delay(eatBackoff)
      return
    end

    -- regen dropped since last check means food was consumed, reset backoff
    if regenTime < lastRegenTime then
      eatBackoff = eatBackoffMin
    end
    lastRegenTime = regenTime

    -- search for food in containers
    for _, container in pairs(g_game.getContainers()) do
      for __, item in ipairs(container:getItems()) do
        for i, foodItem in ipairs(storage.foodItems) do
          if item:getId() == foodItem.id then
            g_game.use(item)
            -- after eating, wait a bit before checking again
            delay(eatBackoff)
            return
          end
        end
      end
    end
  end)
end
UI.Separator()