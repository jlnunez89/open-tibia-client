setDefaultTab("Main")

local blankRuneId = 3147

local function moveRuneToBackpack(runeId)
    if not getLeft() or getLeft():getId() ~= runeId then return end
    -- First, try to stack with existing runes
    for _, container in pairs(getContainers()) do
        for slot, item in ipairs(container:getItems()) do
            if item:getId() == runeId then
                g_game.move(getLeft(), container:getSlotPosition(slot - 1), getLeft():getCount())
                return
            end
        end
    end
    -- Fallback: any backpack with space
    for _, container in pairs(getContainers()) do
        if container:getName():lower():find("backpack") then
            if container:getCapacity() > #container:getItems() then
                g_game.move(getLeft(), container:getSlotPosition(container:getItemsCount()), getLeft():getCount())
                return
            end
        end
    end
end

local function createRuneMaker(label, spellWords, manaCost, spellRuneId, weaponId)
    macro(6000, label, function()
        local leftItem = getLeft()
        local emptyLeft = leftItem == nil
        local leftIsBlank = not emptyLeft and leftItem:getId() == blankRuneId
        local leftIsRune = not emptyLeft and leftItem:getId() == spellRuneId
        local blankRune = findItem(blankRuneId)
        local readyToMake = mana() >= manaCost and (blankRune ~= nil or leftIsBlank)

        -- If a finished rune is still in hand, move it out first
        if leftIsRune then
            moveRuneToBackpack(spellRuneId)
            return
        end

        if not readyToMake then
            if emptyLeft then
                local weapon = findItem(weaponId)
                if weapon then
                    moveToSlot(weapon, SlotLeft, weapon:getCount())
                end
            end
            return
        end

        -- Move blank rune to left hand if needed, then cast in same cycle
        if not leftIsBlank then
            if blankRune then
                moveToSlot(blankRune, SlotLeft, blankRune:getCount())
            end
        end

        -- Sanity check: blank must be in hand to cast
        if not getLeft() or getLeft():getId() ~= blankRuneId then
            return
        end

        say(spellWords)

        -- Move the finished rune to backpack after a short delay
        schedule(math.random(1000, 2000), function() moveRuneToBackpack(spellRuneId) end)
    end)
end

-- Add/remove rune types here:
--   createRuneMaker(label, spellWords, manaCost, spellRuneId, weaponId)
createRuneMaker("Make IHs",  "ad ura gran",      60, 3152, 3305) -- Ultimate Healing, Battle Hammer
createRuneMaker("Make HMMs", "ad ori gran",      70,  3198, 3305) -- Heavy Magic Missile, Battle Hammer
createRuneMaker("Make UHs",  "ad ura vita",      100, 3160, 3305) -- Ultimate Healing, Battle Hammer
createRuneMaker("Make GFBs", "ad ori gran flam", 120, 3191, 3305) -- Great Fireball, Battle Hammer
createRuneMaker("Make SDs",  "ad ori vita vis",  220, 3155, 3305) -- Sudden Death, Battle Hammer
